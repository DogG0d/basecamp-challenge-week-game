# Basecamp Challenge Week

## Game idee

Platformer

## Thema

Onder de Rotterdamse Havens

## Doel

Je moet naar Albert Heijn, maar niet via de straten omdat het regent.

## Features

## Game

- Movement

  - Walk
  - Dashing
  - jumping
  - walljump?
  - interlayer?
  - attack

- Obstacles

  - spikes
  - lava
  - water
  - poision?
  - enemies

- Design

  - textures
  - sprites

- Map
  - Levels

## Storyline

pauze of school
naar de appie
het regent
ondergrondse tunnels
Spring over water

> double jump
> dash
> double jump dash combo?
> walljump
> dummy fight
> test

## Structure

- World group

  - Entity group

    - Enemy group

      - Enemy opject
        - Entity object
          - World object

    - Projectile group
      - Entity object
        - World object

  - Background group

    - Elements

      - Floor objects

        - World object

      - Obstacle object
        - World object

    - Background

  - Player group
    - Player object
      - Entity object
        - World object

---

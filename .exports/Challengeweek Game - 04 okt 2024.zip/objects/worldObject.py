import pygame
from pygame.locals import *

class WorldObject(pygame.sprite.Sprite):
    def __init__(self) -> None:
        pygame.sprite.Sprite.__init__(self)
        
        pass
    

    def update() -> None:
        super().update()
        pass